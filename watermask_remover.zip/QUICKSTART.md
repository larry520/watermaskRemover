# 快速开始指南

## 🚀 5分钟上手

### 第一步：安装依赖

```bash
# 1. 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 2. 安装依赖
pip install -r requirements.txt
```

### 第二步：准备测试图片

将带水印的图片放到项目目录，例如 `test.jpg`

### 第三步：运行！

**方式 1: 命令行（最简单）**

```bash
python main.py remove -i test.jpg -o result.jpg
```

**方式 2: Python 代码**

创建 `quick_test.py`：

```python
from src.watermark_remover import WatermarkRemover

remover = WatermarkRemover()
remover.remove("test.jpg", "result.jpg")
print("完成！")
```

运行：

```bash
python quick_test.py
```

**方式 3: API 服务**

```bash
# 启动服务
uvicorn api.app:app --reload

# 打开浏览器访问
# http://localhost:8000/docs

# 或使用 curl
curl -X POST "http://localhost:8000/upload" \
  -F "file=@test.jpg"
```

## 📝 常见使用场景

### 场景 1: 批量处理文件夹

```bash
# 命令行
python main.py batch -i ./images -o ./results

# 或使用 Python
from src.watermark_remover import WatermarkRemover

remover = WatermarkRemover()
remover.batch_remove("./images", "./results")
```

### 场景 2: 仅检测水印位置

```bash
# 命令行
python main.py detect -i test.jpg

# 或使用 Python
from src.watermark_remover import WatermarkRemover

remover = WatermarkRemover()
detections = remover.detect_only("test.jpg")

for det in detections:
    if det['is_watermark']:
        print(f"水印: {det['text']} at {det['box']}")
```

### 场景 3: 可视化检测结果

```bash
# 命令行
python main.py remove -i test.jpg -o result.jpg -v

# 会额外生成 result_detection.jpg 显示检测到的水印位置
```

```python
# Python
remover = WatermarkRemover()
remover.remove(
    "test.jpg", 
    "result.jpg",
    visualize_detection=True
)
```

### 场景 4: 自定义配置

编辑 `config/config.yaml`：

```yaml
# 修改 OCR 语言
ocr:
  languages: ['ch_sim', 'en', 'ja']  # 添加日语

# 修改修复模型
inpaint:
  model: "mat"  # 改用 MAT 模型
```

## 🎯 进阶技巧

### 技巧 1: 提高检测准确率

```yaml
# config/config.yaml
detection:
  position_filter:
    areas: ['corners']  # 只检测角落的水印
  
  text_filter:
    min_text_length: 3  # 忽略过短的文字
```

### 技巧 2: 处理大图片

```yaml
# config/config.yaml
performance:
  max_image_size: 2048  # 自动缩放超大图片
```

### 技巧 3: 使用不同修复模型

```python
# 对比不同模型效果
models = ['lama', 'mat', 'ldm']

for model in models:
    # 修改配置
    config = {
        'inpaint': {'model': model},
        'ocr': {'languages': ['ch_sim', 'en']}
    }
    
    remover = WatermarkRemover()
    remover.config['inpaint']['model'] = model
    remover.remove(f"test.jpg", f"result_{model}.jpg")
```

## 🐛 常见问题

### Q1: 提示找不到模型？

**A**: 首次运行会自动下载，需要等待几分钟。可以查看：

```bash
ls ~/.EasyOCR/model/
```

### Q2: 内存不足？

**A**: 降低图片分辨率：

```yaml
performance:
  max_image_size: 1024  # 降低到 1024
```

### Q3: GPU 不可用？

**A**: 改用 CPU：

```yaml
ocr:
  gpu: false

inpaint:
  device: "cpu"
```

### Q4: 检测不到水印？

**A**: 尝试：

1. 降低置信度阈值
2. 添加水印关键词
3. 调整检测区域

```yaml
ocr:
  min_confidence: 0.3  # 降低阈值

  watermark_keywords:
    - "您的公司名"
    - "特定文字"

detection:
  position_filter:
    areas: ['all']  # 检测全图
```

## 📦 Docker 部署

```bash
# 构建镜像
docker-compose build

# 启动服务
docker-compose up -d

# 查看日志
docker-compose logs -f
```

访问 http://localhost:8000

## 🎓 学习资源

- 完整文档: `README.md`
- 代码示例: `examples/` 目录
- API 文档: http://localhost:8000/docs（启动服务后）
- 配置说明: `config/config.yaml` 注释

## 💡 提示

1. **首次运行较慢**: 因为需要下载模型
2. **GPU 加速效果显著**: 建议使用 GPU
3. **批量处理时**: 使用并行处理提速
4. **效果不理想**: 尝试调整配置参数

祝使用愉快！如有问题，请查看 README 或提交 Issue。
